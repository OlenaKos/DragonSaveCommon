﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DragonSave
{
    interface IActions
    {
        void UseThrowCardCombination(Gamer gamer, int CardID, Deck cardDeck); //corrsponds changeButton
        void UseMotherMotherCombination(Gamer gamer, Deck cardDeck); //corresponds mmButton
        void UseMotherFatherNestCombination(Gamer gamer, Deck cardDeck); //corresponds to mfnButton
        void UseFatherFatherCombination(Gamer gamer, Deck cardDeck); //corresponds
        void UseThieftCombination(Gamer gamer, Deck cardDeck); //corresponds villainButton
    }
}
