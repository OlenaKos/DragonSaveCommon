﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DragonSave
{
    class GameController
    {




        public void GiveCardsToGamers(List<Gamer> gamers, Deck deck)
        {
            foreach (var gamer in gamers)
            {
                for (int i = 0; i < 4; i++)
                {
                    gamer.GamerCards.Add(deck.deck[0]);
                    deck.deck.RemoveAt(0);
                }
            }
        }

    }
}
