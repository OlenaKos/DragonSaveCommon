﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DragonSave
{
    class Controller
    {

        public Controller()
        {
            GameController gameController = new GameController();
            GamerController gamerController = new GamerController();
        }
        public void StartGame(int gamersCount)
        {
            gamersCount = 2; // for testing goals, have to be removed later
            Game game = new Game(gamersCount);
        }
    }
}
