﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DragonSave
{
    class Villain : Card
    {
        public Villain()
        {
            ImageSource = "/View/image/villain.jpg";
        }
    }
}
