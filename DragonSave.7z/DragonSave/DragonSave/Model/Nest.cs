﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DragonSave
{
    class Nest : Card
    {
        public Nest()
        {
            ImageSource = "/View/image/nest.jpg";
        }
    }
}
